#include <Arduino.h>
#include <WiFi.h>
#include <lvgl.h>
#include <Arduino_GFX_Library.h>
#include <TAMC_GT911.h>

#include "config.h"
#include "boat_data.h"
#include "settings.h"
#include "signalk.h"
#include "alarm.h"
#include "ui.h"

// Page self-registrations fire from static constructors.
// Including the page headers here ensures the translation units are linked.
// (Alternatively, just ensure all page_*.cpp are compiled — PlatformIO does this.)

// ─────────────────────────────────────────────
//  Global boat data + mutex
// ─────────────────────────────────────────────
BoatData gBoat;
SemaphoreHandle_t gBoatMutex = NULL;

// ─────────────────────────────────────────────
//  Display driver  (ST7701 + RGB panel)
// ─────────────────────────────────────────────
Arduino_DataBus* bus = new Arduino_SWSPI(
    GFX_NOT_DEFINED, LCD_CS, LCD_SCK, LCD_SDA, GFX_NOT_DEFINED);

Arduino_ESP32RGBPanel* rgbpanel = new Arduino_ESP32RGBPanel(
    LCD_DE, LCD_VSYNC, LCD_HSYNC, LCD_PCLK,
    LCD_R0, LCD_R1, LCD_R2, LCD_R3, LCD_R4,
    LCD_G0, LCD_G1, LCD_G2, LCD_G3, LCD_G4, LCD_G5,
    LCD_B0, LCD_B1, LCD_B2, LCD_B3, LCD_B4,
    1, 40, 2, 44,   // hsync polarity, front porch, pulse, back porch
    1, 16, 2, 18    // vsync polarity, front porch, pulse, back porch
);

Arduino_ST7701_RGBPanel* gfx = new Arduino_ST7701_RGBPanel(
    rgbpanel, bus, LCD_RST, false, DISPLAY_WIDTH, DISPLAY_HEIGHT);

// ─────────────────────────────────────────────
//  GT911 touch
// ─────────────────────────────────────────────
TAMC_GT911 touch(TOUCH_SDA, TOUCH_SCL, TOUCH_INT, TOUCH_RST,
                 DISPLAY_WIDTH, DISPLAY_HEIGHT);

// ─────────────────────────────────────────────
//  LVGL buffers
// ─────────────────────────────────────────────
static lv_disp_draw_buf_t draw_buf;
static lv_color_t* buf1 = nullptr;
static lv_color_t* buf2 = nullptr;

static void lvgl_flush_cb(lv_disp_drv_t* drv, const lv_area_t* area, lv_color_t* px_map) {
    gfx->draw16bitRGBBitmap(area->x1, area->y1,
        (uint16_t*)px_map,
        area->x2 - area->x1 + 1,
        area->y2 - area->y1 + 1);
    lv_disp_flush_ready(drv);
}

static void lvgl_touch_cb(lv_indev_drv_t*, lv_indev_data_t* data) {
    touch.read();
    if (touch.isTouched && touch.touches > 0) {
        data->state   = LV_INDEV_STATE_PRESSED;
        data->point.x = touch.points[0].x;
        data->point.y = touch.points[0].y;
    } else {
        data->state = LV_INDEV_STATE_RELEASED;
    }
}

// ─────────────────────────────────────────────
//  WiFi
// ─────────────────────────────────────────────
static void wifi_connect() {
    Serial.printf("[WiFi] Connecting to %s", WIFI_SSID);
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    uint32_t t = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t < 15000) {
        delay(500); Serial.print(".");
        lv_timer_handler();
    }
    if (WiFi.status() == WL_CONNECTED)
        Serial.printf("\n[WiFi] IP: %s\n", WiFi.localIP().toString().c_str());
    else
        Serial.println("\n[WiFi] Failed — retrying in background");
}

// ─────────────────────────────────────────────
//  setup()
// ─────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    Serial.println("\n[BOOT] Boat Display v2 starting...");

    gBoatMutex = xSemaphoreCreateMutex();

    // Load settings from NVS
    settings_init();

    // Backlight
    ledcSetup(0, 5000, 8);
    ledcAttachPin(LCD_BL, 0);
    ledcWrite(0, gSettings.brightness);

    // Display
    if (!gfx->begin()) {
        Serial.println("[ERROR] GFX init failed");
        while (1) delay(100);
    }
    gfx->fillScreen(BLACK);

    // Touch
    Wire.begin(TOUCH_SDA, TOUCH_SCL);
    touch.begin();
    touch.setRotation(ROTATION_NORMAL);

    // LVGL
    lv_init();
    size_t buf_size = DISPLAY_WIDTH * LV_BUF_LINES;
    buf1 = (lv_color_t*)heap_caps_malloc(buf_size * sizeof(lv_color_t), MALLOC_CAP_SPIRAM);
    buf2 = (lv_color_t*)heap_caps_malloc(buf_size * sizeof(lv_color_t), MALLOC_CAP_SPIRAM);
    if (!buf1 || !buf2) {
        buf1 = (lv_color_t*)heap_caps_malloc(buf_size * sizeof(lv_color_t), MALLOC_CAP_DMA);
        buf2 = (lv_color_t*)heap_caps_malloc(buf_size * sizeof(lv_color_t), MALLOC_CAP_DMA);
    }
    lv_disp_draw_buf_init(&draw_buf, buf1, buf2, buf_size);

    static lv_disp_drv_t disp_drv;
    lv_disp_drv_init(&disp_drv);
    disp_drv.hor_res  = DISPLAY_WIDTH;
    disp_drv.ver_res  = DISPLAY_HEIGHT;
    disp_drv.flush_cb = lvgl_flush_cb;
    disp_drv.draw_buf = &draw_buf;
    lv_disp_drv_register(&disp_drv);

    static lv_indev_drv_t indev_drv;
    lv_indev_drv_init(&indev_drv);
    indev_drv.type    = LV_INDEV_TYPE_POINTER;
    indev_drv.read_cb = lvgl_touch_cb;
    lv_indev_drv_register(&indev_drv);

    // Alarm engine (I2S audio + evaluation task)
    alarm_init();

    // Build UI (all pages self-registered at this point)
    ui_init();

    // WiFi + SignalK
    wifi_connect();
    signalk_start();

    // Startup beep
    alarm_beep(AlarmPattern::BEEP_DOUBLE);

    Serial.println("[BOOT] Ready");
}

// ─────────────────────────────────────────────
//  loop()
// ─────────────────────────────────────────────
static uint32_t last_ui_update   = 0;
static uint32_t last_alarm_tick  = 0;
static uint32_t last_wifi_check  = 0;

void loop() {
    lv_timer_handler();
    signalk_loop();

    uint32_t now = millis();

    if (now - last_ui_update >= 250) {
        last_ui_update = now;
        ui_update();
    }

    if (now - last_alarm_tick >= 1000) {
        last_alarm_tick = now;
        alarm_tick();
    }

    if (now - last_wifi_check >= 10000) {
        last_wifi_check = now;
        if (WiFi.status() != WL_CONNECTED) WiFi.reconnect();
    }

    delay(5);
}
