# CMakeLists.txt Changes

## What Changed

### Added to SRCS (source files):
```cmake
"boat_mqtt.cpp"
```

### Added to REQUIRES (component dependencies):
```cmake
mqtt
```

## Full Section
```cmake
idf_component_register(
    SRCS
        "main.cpp"
        "boat_data.cpp"
        "settings.cpp"
        "signalk.cpp"
        "boat_mqtt.cpp"          # ← NEW
        "alarm.cpp"
        # ... other files ...
    
    REQUIRES
        esp_wifi
        nvs_flash
        esp_event
        esp_netif
        esp_websocket_client
        mqtt                      # ← NEW
        esp_codec_dev
        driver
        freertos
        log
        esp_http_server
)
```

## Why These Changes?

1. **boat_mqtt.cpp** - Our new MQTT client implementation needs to be compiled
2. **mqtt** - ESP-IDF's built-in MQTT component needs to be linked

## Note
The `mqtt` component is **built into ESP-IDF** - no external dependency or download required. It's part of the standard ESP-IDF framework.
