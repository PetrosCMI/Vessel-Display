#include "boat_mqtt.h"
#include "boat_data.h"
#include "settings.h"
#include "esp_log.h"
#include "esp_event.h"
#include "mqtt_client.h"  // ESP-IDF MQTT client
#include "cJSON.h"
#include <string.h>
#include <math.h>

static const char* TAG = "MQTT";
static esp_mqtt_client_handle_t s_client = NULL;

static inline float rad2deg(float r) { return r * 57.29578f; }
static inline float K2C(float k)     { return k - 273.15f;   }

// ────────────────────────────────────────────────
//  Parse MQTT message payload
//  SignalK publishes as JSON: {"value": 12.34}
//  Battery ESP32s publish as plain text: "12.34"
// ────────────────────────────────────────────────
static float parse_value(const char* data, int len) {
    if (!data || len <= 0) return NAN;
    
    // Try JSON parse first (SignalK format)
    char* buf = (char*)malloc(len + 1);
    if (!buf) return NAN;
    memcpy(buf, data, len);
    buf[len] = '\0';
    
    cJSON* root = cJSON_Parse(buf);
    if (root) {
        cJSON* value = cJSON_GetObjectItem(root, "value");
        float result = NAN;
        if (cJSON_IsNumber(value)) {
            result = (float)value->valuedouble;
        }
        cJSON_Delete(root);
        free(buf);
        return result;
    }
    
    // Fallback: plain text number
    float result = atof(buf);
    free(buf);
    return result;
}

// Parse position from SignalK JSON: {"value": {"latitude": 49.123, "longitude": -123.456}}
static bool parse_position(const char* data, int len, double* lat, double* lon) {
    if (!data || len <= 0) return false;
    
    char* buf = (char*)malloc(len + 1);
    if (!buf) return false;
    memcpy(buf, data, len);
    buf[len] = '\0';
    
    cJSON* root = cJSON_Parse(buf);
    if (!root) {
        free(buf);
        return false;
    }
    
    bool success = false;
    cJSON* value = cJSON_GetObjectItem(root, "value");
    if (value) {
        cJSON* lat_json = cJSON_GetObjectItem(value, "latitude");
        cJSON* lon_json = cJSON_GetObjectItem(value, "longitude");
        
        if (cJSON_IsNumber(lat_json) && cJSON_IsNumber(lon_json)) {
            *lat = lat_json->valuedouble;
            *lon = lon_json->valuedouble;
            success = true;
        }
    }
    
    cJSON_Delete(root);
    free(buf);
    return success;
}

// ────────────────────────────────────────────────
//  MQTT event handler
// ────────────────────────────────────────────────
static void mqtt_event_handler(void* handler_args, esp_event_base_t base,
                               int32_t event_id, void* event_data) {
    esp_mqtt_event_handle_t event = (esp_mqtt_event_handle_t)event_data;
    
    switch (event_id) {
        case MQTT_EVENT_CONNECTED:
            ESP_LOGI(TAG, "Connected to broker");
            if (xSemaphoreTake(gBoatMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
                gBoat.mqtt_connected = true;
                xSemaphoreGive(gBoatMutex);
            }
            
            // Subscribe to all topics
            esp_mqtt_client_subscribe(s_client, MQTT_SOG, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_STW, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_COG, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_HDG_TRUE, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_HDG_MAG, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_POSITION, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_DEPTH, 0);
            
            esp_mqtt_client_subscribe(s_client, MQTT_AWS, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_AWA, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_TWS, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_TWA, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_TWD, 0);
            
            esp_mqtt_client_subscribe(s_client, MQTT_WATER_TEMP, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_AIR_TEMP, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_PRESSURE, 0);
            
            // Battery topics
            esp_mqtt_client_subscribe(s_client, MQTT_BATT_HOUSE_V, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_BATT_HOUSE_A, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_BATT_HOUSE_SOC, 0);
            
            esp_mqtt_client_subscribe(s_client, MQTT_BATT_HOUSE_LI_V, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_BATT_HOUSE_LI_A, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_BATT_HOUSE_LI_SOC, 0);
            
            esp_mqtt_client_subscribe(s_client, MQTT_BATT_START_V, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_BATT_START_A, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_BATT_START_SOC, 0);
            
            esp_mqtt_client_subscribe(s_client, MQTT_BATT_FWD_V, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_BATT_FWD_A, 0);
            esp_mqtt_client_subscribe(s_client, MQTT_BATT_FWD_SOC, 0);
            
            ESP_LOGI(TAG, "Subscribed to all topics");
            break;
            
        case MQTT_EVENT_DISCONNECTED:
            ESP_LOGI(TAG, "Disconnected from broker");
            if (xSemaphoreTake(gBoatMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
                gBoat.mqtt_connected = false;
                xSemaphoreGive(gBoatMutex);
            }
            break;
            
        case MQTT_EVENT_DATA: {
            char topic[128] = {};
            int topic_len = event->topic_len < 127 ? event->topic_len : 127;
            memcpy(topic, event->topic, topic_len);
            
            ESP_LOGD(TAG, "Topic: %s, Data: %.*s", topic, event->data_len, event->data);
            
            // Navigation
            if (strcmp(topic, MQTT_SOG) == 0)
                boatSet(gBoat.sog_ms, parse_value(event->data, event->data_len));
            else if (strcmp(topic, MQTT_STW) == 0)
                boatSet(gBoat.stw_ms, parse_value(event->data, event->data_len));
            else if (strcmp(topic, MQTT_COG) == 0)
                boatSet(gBoat.cog_deg, rad2deg(parse_value(event->data, event->data_len)));
            else if (strcmp(topic, MQTT_HDG_TRUE) == 0)
                boatSet(gBoat.heading_deg, rad2deg(parse_value(event->data, event->data_len)));
            else if (strcmp(topic, MQTT_HDG_MAG) == 0) {
                if (xSemaphoreTake(gBoatMutex, pdMS_TO_TICKS(5)) == pdTRUE) {
                    if (isnan(gBoat.heading_deg))
                        gBoat.heading_deg = rad2deg(parse_value(event->data, event->data_len));
                    xSemaphoreGive(gBoatMutex);
                }
            }
            else if (strcmp(topic, MQTT_POSITION) == 0) {
                double lat, lon;
                if (parse_position(event->data, event->data_len, &lat, &lon)) {
                    if (xSemaphoreTake(gBoatMutex, pdMS_TO_TICKS(5)) == pdTRUE) {
                        gBoat.lat = lat;
                        gBoat.lon = lon;
                        gBoat.gps_valid = true;
                        gBoat.last_update_ms = xTaskGetTickCount() * portTICK_PERIOD_MS;
                        xSemaphoreGive(gBoatMutex);
                        ESP_LOGD(TAG, "Position: %.6f, %.6f", lat, lon);
                    }
                }
            }
            else if (strcmp(topic, MQTT_DEPTH) == 0) {
                float depth = parse_value(event->data, event->data_len);
                if (xSemaphoreTake(gBoatMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
                    gBoat.depth_m = depth;
                    if (isnan(gBoat.depth_max_m) || depth > gBoat.depth_max_m)
                        gBoat.depth_max_m = depth;
                    if (isnan(gBoat.depth_min_m) || depth < gBoat.depth_min_m)
                        gBoat.depth_min_m = depth;
                    gBoat.last_update_ms = xTaskGetTickCount() * portTICK_PERIOD_MS;
                    xSemaphoreGive(gBoatMutex);
                }
            }
            
            // Wind
            else if (strcmp(topic, MQTT_AWS) == 0) {
                float aws = parse_value(event->data, event->data_len);
                if (xSemaphoreTake(gBoatMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
                    gBoat.aws_ms = aws;
                    if (isnan(gBoat.aws_max_ms) || aws > gBoat.aws_max_ms)
                        gBoat.aws_max_ms = aws;
                    gBoat.last_update_ms = xTaskGetTickCount() * portTICK_PERIOD_MS;
                    xSemaphoreGive(gBoatMutex);
                }
            }
            else if (strcmp(topic, MQTT_AWA) == 0)
                boatSet(gBoat.awa_deg, rad2deg(parse_value(event->data, event->data_len)));
            else if (strcmp(topic, MQTT_TWS) == 0)
                boatSet(gBoat.tws_ms, parse_value(event->data, event->data_len));
            else if (strcmp(topic, MQTT_TWA) == 0)
                boatSet(gBoat.twa_deg, rad2deg(parse_value(event->data, event->data_len)));
            else if (strcmp(topic, MQTT_TWD) == 0)
                boatSet(gBoat.twd_deg, rad2deg(parse_value(event->data, event->data_len)));
            
            // Environment
            else if (strcmp(topic, MQTT_WATER_TEMP) == 0)
                boatSet(gBoat.water_temp_c, K2C(parse_value(event->data, event->data_len)));
            else if (strcmp(topic, MQTT_AIR_TEMP) == 0)
                boatSet(gBoat.air_temp_c, K2C(parse_value(event->data, event->data_len)));
            else if (strcmp(topic, MQTT_PRESSURE) == 0)
                boatSet(gBoat.pressure_hpa, parse_value(event->data, event->data_len) / 100.0f);
            
            // Battery data (plain text from ESP32 sensors)
            else if (strcmp(topic, MQTT_BATT_HOUSE_V) == 0)
                boatSet(gBoat.house_v, parse_value(event->data, event->data_len));
            else if (strcmp(topic, MQTT_BATT_HOUSE_A) == 0)
                boatSet(gBoat.house_a, parse_value(event->data, event->data_len));
            else if (strcmp(topic, MQTT_BATT_HOUSE_SOC) == 0)
                boatSet(gBoat.house_soc, parse_value(event->data, event->data_len));
            
            else if (strcmp(topic, MQTT_BATT_HOUSE_LI_V) == 0)
                boatSet(gBoat.house_v_li, parse_value(event->data, event->data_len));
            else if (strcmp(topic, MQTT_BATT_HOUSE_LI_A) == 0)
                boatSet(gBoat.house_a_li, parse_value(event->data, event->data_len));
            else if (strcmp(topic, MQTT_BATT_HOUSE_LI_SOC) == 0)
                boatSet(gBoat.house_li_soc, parse_value(event->data, event->data_len));
            
            else if (strcmp(topic, MQTT_BATT_START_V) == 0)
                boatSet(gBoat.start_batt_v, parse_value(event->data, event->data_len));
            else if (strcmp(topic, MQTT_BATT_START_A) == 0)
                boatSet(gBoat.start_batt_a, parse_value(event->data, event->data_len));
            else if (strcmp(topic, MQTT_BATT_START_SOC) == 0)
                boatSet(gBoat.start_batt_soc, parse_value(event->data, event->data_len));
            
            else if (strcmp(topic, MQTT_BATT_FWD_V) == 0)
                boatSet(gBoat.forward_v, parse_value(event->data, event->data_len));
            else if (strcmp(topic, MQTT_BATT_FWD_A) == 0)
                boatSet(gBoat.forward_a, parse_value(event->data, event->data_len));
            else if (strcmp(topic, MQTT_BATT_FWD_SOC) == 0)
                boatSet(gBoat.forward_soc, parse_value(event->data, event->data_len));
            
            break;
        }
        
        case MQTT_EVENT_ERROR:
            ESP_LOGW(TAG, "MQTT error");
            break;
            
        default:
            break;
    }
}

// ────────────────────────────────────────────────
//  Public API
// ────────────────────────────────────────────────
void mqtt_start(void) {
    // Use settings for broker address, fall back to defaults
    const char* host = gSettings.mqtt_host[0] ? gSettings.mqtt_host : "192.168.1.100";
    uint16_t port = gSettings.mqtt_port ? gSettings.mqtt_port : 1883;
    
    char uri[128];
    snprintf(uri, sizeof(uri), "mqtt://%s:%d", host, port);
    
    esp_mqtt_client_config_t cfg = {};
    cfg.broker.address.uri = uri;
    cfg.network.reconnect_timeout_ms = 3000;
    cfg.network.timeout_ms = 5000;
    cfg.buffer.size = 4096;
    
    s_client = esp_mqtt_client_init(&cfg);
    esp_mqtt_client_register_event(s_client, MQTT_EVENT_ANY, mqtt_event_handler, NULL);
    esp_mqtt_client_start(s_client);
    
    ESP_LOGI(TAG, "Connecting to %s", uri);
}

void mqtt_stop(void) {
    if (s_client) {
        esp_mqtt_client_stop(s_client);
        esp_mqtt_client_destroy(s_client);
        s_client = NULL;
    }
    if (xSemaphoreTake(gBoatMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
        gBoat.mqtt_connected = false;
        xSemaphoreGive(gBoatMutex);
    }
}
