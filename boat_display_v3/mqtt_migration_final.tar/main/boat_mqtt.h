#pragma once

// MQTT broker connection API
void mqtt_start(void);
void mqtt_stop(void);

// MQTT topic paths for NMEA data (from SignalK via MQTT)
// These match SignalK's default MQTT topic structure
#define MQTT_BASE "signalk/vessels/self/"

// Navigation topics
#define MQTT_SOG        MQTT_BASE "navigation/speedOverGround"
#define MQTT_STW        MQTT_BASE "navigation/speedThroughWater"
#define MQTT_COG        MQTT_BASE "navigation/courseOverGroundTrue"
#define MQTT_HDG_TRUE   MQTT_BASE "navigation/headingTrue"
#define MQTT_HDG_MAG    MQTT_BASE "navigation/headingMagnetic"
#define MQTT_POSITION   MQTT_BASE "navigation/position"
#define MQTT_DEPTH      MQTT_BASE "environment/depth/belowTransducer"

// Wind topics
#define MQTT_AWS        MQTT_BASE "environment/wind/speedApparent"
#define MQTT_AWA        MQTT_BASE "environment/wind/angleApparent"
#define MQTT_TWS        MQTT_BASE "environment/wind/speedTrue"
#define MQTT_TWA        MQTT_BASE "environment/wind/angleTrue"
#define MQTT_TWD        MQTT_BASE "environment/wind/directionTrue"

// Environment topics
#define MQTT_WATER_TEMP MQTT_BASE "environment/water/temperature"
#define MQTT_AIR_TEMP   MQTT_BASE "environment/outside/temperature"
#define MQTT_PRESSURE   MQTT_BASE "environment/outside/pressure"

// Battery topics (from your ESP32 battery monitors)
#define MQTT_BATT_HOUSE_V   "boat/battery/house/voltage"
#define MQTT_BATT_HOUSE_A   "boat/battery/house/current"
#define MQTT_BATT_HOUSE_SOC "boat/battery/house/soc"

#define MQTT_BATT_HOUSE_LI_V   "boat/battery/house_li/voltage"
#define MQTT_BATT_HOUSE_LI_A   "boat/battery/house_li/current"
#define MQTT_BATT_HOUSE_LI_SOC "boat/battery/house_li/soc"

#define MQTT_BATT_START_V   "boat/battery/starter/voltage"
#define MQTT_BATT_START_A   "boat/battery/starter/current"
#define MQTT_BATT_START_SOC "boat/battery/starter/soc"

#define MQTT_BATT_FWD_V   "boat/battery/forward/voltage"
#define MQTT_BATT_FWD_A   "boat/battery/forward/current"
#define MQTT_BATT_FWD_SOC "boat/battery/forward/soc"
